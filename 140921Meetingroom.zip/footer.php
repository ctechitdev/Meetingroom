<?PHP 
   
			?>		

 <footer class="footer text-center">
                © 2020 Power by ICT - KPCompanyLao
            </footer>