
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
	<style>
	.font{font-family:phetsarath OT;}
	.table td {
	text-align: center;   
	}
	.table th {
	text-align: center;   
	}
	.td-staff-name{
		 width: 20%;
	}
	.td-depart{
		 width: 20%;
	}
	.td-posotion{
		 width: 20%;
	}
  
  
}
</style>
 
	
<link rel="icon" type="image/png" sizes="16x16" href="assets/images/kpicon.png">
<title> ໂປຣແກຣມນຳໃຊ້ຫ້ອງປະຊຸມ </title> 

<link href="css/rename-bootstrap.min.css" rel="stylesheet"> 
<link href="css/newstyle.css" rel="stylesheet">
<link href="css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" /> 
<link href="css/default.css" id="theme" rel="stylesheet"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap-clockpicker.min.css">
<link rel="stylesheet" href="css/date_picker.css">

<script src="js/jquery.min.js"></script>
	
   
</head>